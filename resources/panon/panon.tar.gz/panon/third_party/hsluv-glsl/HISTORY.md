## History

v0.0 July 21, 2016
	- Initial beta release!

v1.0 July 21, 2016
	- added husl_ prefix to internal functions to avoid namespace pollution
	- removed need for lookup texture
	- more accurate math

v1.1 July 22, 2016
	- simplified and cleaned up code
	- optimisation

v2.0 July 22, 2016
	- all functions accept color without alpha
	- functions accept floats as well as vectors

v3.0 July 25, 2016
	- changed api to camelCase

v3.1 July 25, 2016
	- cleaned up code
	- functions written for vec3's first to keep logic cleaner

v3.2 July 25, 2016
	- fixed hulsp that was broken

v4.0 December 18, 2016
	- changed name to HSLUV

v4.1 January 5, 2017
	- Fixed https://github.com/williammalo/hsluv-glsl/issues/1

v4.2 May 18, 2017
	- Fixed https://github.com/williammalo/hsluv-glsl/issues/1 again
	- Simplified and optimised code a bit