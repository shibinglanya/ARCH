mkdir build
cd build 
cmake ..
make install DESTDIR=~/.local/share/locale/
